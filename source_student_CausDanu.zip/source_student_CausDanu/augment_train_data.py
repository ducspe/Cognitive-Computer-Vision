from datareader import DataReader
import matplotlib.pyplot as plt
import numpy as np
import os
import scipy.misc as im

print(os.getcwd())
def plot_gallery(images, titles, n_row=3, n_col=4):
    """Helper function to plot a gallery of portraits"""
    plt.figure(figsize=(3 * n_col, 3 * n_row))
    plt.subplots_adjust(bottom=0, left=.01, right=.99, top=.90, hspace=.35)
    for i in range(n_row * n_col):
        plt.subplot(n_row, n_col, i + 1)
        plt.imshow(images[i], cmap='gray')
        plt.title(titles[i], size=12)
        plt.xticks(())
        plt.yticks(())

batchsize = 1200


train_data = DataReader('data/ccv_data/train')
images, fixations, filenames = train_data.get_batch(batchsize)


ind = 0
for img in images:
    im.toimage(np.flipud(img)).save(os.path.join("augmented/updown/images", "ud_%s" % filenames[ind]))
    im.toimage(np.fliplr(img)).save(os.path.join("augmented/leftright/images", "lr_%s" %  filenames[ind]))
    ind += 1



ind = 0
for fix in fixations:
    im.toimage(np.flipud(fix.reshape(224,224))).save(os.path.join("augmented/updown/fixations", "ud_%s" %  filenames[ind]))
    im.toimage(np.fliplr(fix.reshape(224,224))).save(os.path.join("augmented/leftright/fixations", "lr_%s" % filenames[ind]))
    ind += 1


################################################################# Reading the data #################################################################


lr_data = DataReader('augmented/leftright')
ud_data = DataReader('augmented/updown')


lr_images, lr_fixations, lr_filenames = lr_data.get_batch(batchsize)
ud_images, ud_fixations, ud_filenames = ud_data.get_batch(batchsize)


index = 1199
img = images[index]
fix = fixations[index]
imgud = ud_images[index]
fixud = ud_fixations[index]
imglr = lr_images[index]
fixlr = lr_fixations[index]
my_images = [img, imgud, imglr, fix.reshape(224,224), fixud.reshape(224,224), fixlr.reshape(224,224)]
titles = [filenames[index], "ud_%s" % filenames[index], "lr_%s" % filenames[index], "fixation%s" % filenames[index], "ud_fixation%s" % filenames[index], "lr_fixation%s" % filenames[index]]

plot_gallery(my_images, titles, 3, 2)

plt.show()

