
from datareader import DataReader
from my_data_reader import MyDataReader
from kld import KLD

val_data = DataReader('../Exercise5/data/ccv_data/val')
prediction_directory = MyDataReader('./predictions_6350')

sum = 0
for i in range(1201, 1601):
    ground_image = val_data.read_fixation_image(str(i)+".jpg")
    prediction = prediction_directory.read_image(str(i)+".jpg")
    k = KLD(prediction, ground_image)
    sum += k

average_kld = sum/400
print("average kld: ", average_kld)