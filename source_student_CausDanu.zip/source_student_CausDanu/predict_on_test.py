import tensorflow as tf
import numpy as np
import os
from datareader import DataReader
import scipy.misc as im

test_data = DataReader('../Exercise5/data/ccv_data/test')

# Set up CNN
x = tf.placeholder(tf.float32, (None, 224, 224, 3))  # input image
y = tf.placeholder(tf.float32, (None, 224, 224, 1))  # target eye fixation map


conv1 = tf.layers.conv2d(x, filters=32, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d())
conv2 = tf.layers.conv2d(conv1, filters=32, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d())
pool1 = tf.layers.max_pooling2d(conv2, pool_size=[2, 2], strides=2, padding="same")


conv3 = tf.layers.conv2d(conv2, filters=64, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d())



conv4 = tf.layers.conv2d(conv3, filters=64, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d())
pool2 = tf.layers.max_pooling2d(conv4, pool_size=[2, 2], strides=2, padding="same")

conv5 = tf.layers.conv2d(pool2, filters=128, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d())
conv6 = tf.layers.conv2d(conv5, filters=128, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d())
pool3 = tf.layers.max_pooling2d(conv6, pool_size=[2, 2], strides=1, padding="same")

conv7 = tf.layers.conv2d(pool3, filters=128, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d())
conv8 = tf.layers.conv2d(conv7, filters=128, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d())

multilevel_features = tf.concat([pool2, pool3, conv8], axis=3) # use dropout on this level. Start with 0.5...

drop_out = tf.nn.dropout(multilevel_features, 0.5)  # DROP-OUT here

conv9 = tf.layers.conv2d(drop_out, filters=64, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d())
conv10 = tf.layers.conv2d(conv9, filters=1, kernel_size=[1, 1], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d())
upsampled_output = tf.image.resize_images(conv10, (224, 224), method=tf.image.ResizeMethod.BICUBIC)

# Normalize output fixation maps
wmax = tf.reduce_max(upsampled_output, axis=2, keepdims=True)  # along width dimension
output_max = tf.reduce_max(wmax, axis=1, keepdims=True)  # along height dimension
normalized_output = upsampled_output / output_max

saver = tf.train.Saver()
b = 0

with tf.Session() as sess:

    saver.restore(sess, "./my-model-6350")  # choose what model to use

    while b < 400:

        b += 1
        if b % 400 == 0:
            print('Running saliency images conversion')

            # Create a directory for the saved predictions if it does not already exist
            prediction_directory = './predictions_for_test_data' + str(b)
            if not os.path.exists(prediction_directory):
                os.makedirs(prediction_directory)

            for vb in range(400):
                test_images, test_filenames = test_data.get_test_batch(1)
                predictions = sess.run([normalized_output],
                                       feed_dict={x: test_images})

                for p, fn in zip(predictions, test_filenames):
                    pred_file_name = fn.split(".")[0] + "_prediction.jpg"
                    prediction_name = os.path.join(prediction_directory, pred_file_name)
                    p_arr = (p * 255.0).astype(np.uint8)
                    p_image = im.toimage(p_arr.reshape(224, 224))
                    p_image.save(prediction_name)
