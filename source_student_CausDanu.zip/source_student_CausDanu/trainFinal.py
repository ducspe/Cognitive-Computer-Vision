import tensorflow as tf
import numpy as np
import os
from datareader import DataReader
from PIL import Image
import h5py

def get_weights_vgg16(f, id):
    g = f['layer_{}'.format(id)]
    return [g['param_{}'.format(p)] for p in range(g.attrs['nb_params'])]

train_data = DataReader('../Exercise5/data/ccv_data/train')
val_data = DataReader('../Exercise5/data/ccv_data/val')

batchsize = 10

num_training_images = train_data.num_images
num_training_batches_per_epoch = train_data.num_batches_of_size(batchsize)
num_validation_batches_per_epoch = val_data.num_batches_of_size(batchsize)

# Choose how many batches to train for
num_epochs = 15
num_training_batches = num_epochs * num_training_batches_per_epoch

# Choose how often to validate
validation_interval = 50  # every 50 batches

# Set to True to start from a checkpoint
use_checkpoint = False

# Set up CNN
x = tf.placeholder(tf.float32, (None, 224, 224, 3))  # input image
y = tf.placeholder(tf.float32, (None, 224, 224, 1))  # target eye fixation map

f = h5py.File("vgg16_weights.h5")
weights = tf.initializers.constant(get_weights_vgg16(f, 3))
regularizer = tf.contrib.layers.l2_regularizer(scale=0.1)

conv1 = tf.layers.conv2d(x, filters=32, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d(), kernel_regularizer=regularizer)
conv2 = tf.layers.conv2d(conv1, filters=32, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d(), kernel_regularizer=regularizer)
pool1 = tf.layers.max_pooling2d(conv2, pool_size=[2, 2], strides=2, padding="same")


conv3 = tf.layers.conv2d(conv2, filters=64, kernel_size=[3, 3], padding="same", activation=tf.nn.relu)



conv4 = tf.layers.conv2d(conv3, filters=64, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d(), kernel_regularizer=regularizer)
pool2 = tf.layers.max_pooling2d(conv4, pool_size=[2, 2], strides=2, padding="same")

conv5 = tf.layers.conv2d(pool2, filters=128, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d(), kernel_regularizer=regularizer)
conv6 = tf.layers.conv2d(conv5, filters=128, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d(), kernel_regularizer=regularizer)
pool3 = tf.layers.max_pooling2d(conv6, pool_size=[2, 2], strides=1, padding="same")

conv7 = tf.layers.conv2d(pool3, filters=128, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d(), kernel_regularizer=regularizer)
conv8 = tf.layers.conv2d(conv7, filters=128, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d(), kernel_regularizer=regularizer)

multilevel_features = tf.concat([pool2, pool3, conv8], axis=3) # use dropout on this level. Start with 0.5...

drop_out = tf.nn.dropout(multilevel_features, 0.5)  # DROP-OUT here

conv9 = tf.layers.conv2d(drop_out, filters=64, kernel_size=[3, 3], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d(), kernel_regularizer=regularizer) # use Xavier initialization
conv10 = tf.layers.conv2d(conv9, filters=1, kernel_size=[1, 1], padding="same", activation=tf.nn.relu, kernel_initializer=tf.contrib.layers.xavier_initializer_conv2d(), kernel_regularizer=regularizer) # Use Xavier initialization
upsampled_output = tf.image.resize_images(conv10, (224, 224), method=tf.image.ResizeMethod.BICUBIC)

# Normalize output fixation maps
wmax = tf.reduce_max(upsampled_output, axis=2, keepdims=True)  # along width dimension
output_max = tf.reduce_max(wmax, axis=1, keepdims=True)  # along height dimension
normalized_output = upsampled_output / output_max

# Loss function
alpha = 1.1
loss = tf.reduce_mean(tf.square((1.0 / (alpha - y)) * (normalized_output - y)))
loss_summary = tf.summary.scalar(name="loss", tensor=loss)

optimizer = tf.train.AdamOptimizer(learning_rate=0.001,
    beta1=0.9,
    beta2=0.995,
    epsilon=1e-04,
    use_locking=False,
    name='Adam'
)
train_op = optimizer.minimize(loss)

saver = tf.train.Saver()

validation_acc_list = []
count_validation_accuracy_plateau = 0
b = 0

with tf.Session() as sess:

    summary_writer = tf.summary.FileWriter(logdir="./", graph=sess.graph)

    if use_checkpoint:
        saver.restore(sess, "./my-model-100")  # For example, replace by name of model you want to restore
    else:
        sess.run(tf.global_variables_initializer())


    while True:
        b += 1

        tr_images, tr_fixations, tr_filenames = train_data.get_batch(batchsize)

        batch_loss, batch_loss_summary, _ = sess.run([loss, loss_summary, train_op],
                                                     feed_dict={x: tr_images, y: tr_fixations})
        summary_writer.add_summary(batch_loss_summary, global_step=b)
        print('Batch ' + str(b) + ', loss: ' + str(batch_loss))

        if b % validation_interval == 0:
            print('Running validation')
            total_eval_loss = 0.0

            # Create a directory for the saved predictions if it does not already exist
            prediction_directory = './predictions_' + str(b)
            if not os.path.exists(prediction_directory):
                os.makedirs(prediction_directory)

            # Validation loop with saving of predictions
            for vb in range(num_validation_batches_per_epoch):
                val_images, val_fixations, val_filenames = val_data.get_batch(batchsize)
                batch_eval_loss, predictions = sess.run([loss, normalized_output],
                                                        feed_dict={x: val_images, y: val_fixations})
                total_eval_loss += batch_eval_loss

                for p, fn in zip(predictions, val_filenames):
                    prediction_name = os.path.join(prediction_directory, fn)
                    p_arr = (p * 255.0).astype(np.uint8)
                    p_image = Image.fromarray(p_arr[:, :, 0])
                    p_image.save(prediction_name)

            avg_eval_loss = total_eval_loss / num_validation_batches_per_epoch
            print('Average validation loss: ' + str(avg_eval_loss))

            if validation_acc_list and avg_eval_loss < validation_acc_list[-1]:
                count_validation_accuracy_plateau += 1

            validation_acc_list.append(avg_eval_loss)
            print("List of average validation accuracies: ", validation_acc_list)
            print("Count of accuracy improvements: ", count_validation_accuracy_plateau)
            if b / num_training_batches > 1:
                print("Reached the number of desired training batches but continuing train...")
                print("b = ", b)

            summary = tf.Summary()
            summary.value.add(tag="validation_loss", simple_value=avg_eval_loss)
            summary_writer.add_summary(summary, global_step=b)

            # Save the current model after running validation
            saver_path = saver.save(sess, "./my-model", global_step=b)
